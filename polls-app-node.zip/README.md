# polls-app-node
basic voting polls app nodejs
