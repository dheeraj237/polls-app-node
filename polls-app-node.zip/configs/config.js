module.exports = {
    env: process.env.NODE_ENV || 'dev',
    hostname: 'localhost',
    port: 3003,
    dbHost: "mongodb+srv://root:root@node-test-gf5xp.mongodb.net/test?retryWrites=true&w=majority"

};